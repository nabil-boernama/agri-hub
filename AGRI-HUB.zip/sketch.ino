#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <DHT.h>
#include <ESP32Servo.h>
#include <Preferences.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// Pins Configuration
#define DHTPIN 4
#define ONE_WIRE_BUS 15
#define TRIG_PIN 5
#define ECHO_PIN 18
#define FLOW_SENSOR_PIN 35
#define TDS_PIN 36
#define PH_PIN 39
#define LDR_PIN 34
#define PUMP_PIN 16
#define PARANET_PIN 17

// Relay Pins
const int pinRelay[9] = {25, 12, 23, 13, 14, 27, 26, 33, 32};

// WiFi & MQTT Configuration
const char* ssid        = "Wokwi-GUEST";
const char* password    = "";
const char* mqtt_server = "obbee6f8.ala.eu-central-1.emqxsl.com"; // EMQX Address
const int   mqtt_port   = 8883;                                   // SSL/TLS Port
const char* mqtt_user   = "agri-hub";
const char* mqtt_pass   = "agri-hub67";

// Time Configuration (NTP)
Preferences preferences;         
const char* ntpServer = "pool.ntp.org";
int zona_waktu_aktif = 7;                                // Default WIB (GMT+7)

// Initialization
WiFiClientSecure espClient;
PubSubClient client(espClient);
DHT dht(DHTPIN, DHT22);
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);
Servo servoPump;
Servo servoParanet;
LiquidCrystal_I2C lcd(0x27, 20, 4);

// Variables
volatile unsigned long flowPulses = 0;
float RL10 = 50;                                          // LDR resistance value at standart cons
float GAMMA = 0.7;                                        // LDR characteristic coefficient 
const float JARAK_AIR_RENDAH = 100.0;                     // Distance from sensor ro water surface inside water tank
const float JARAK_AIR_PENUH = 15.0;
const unsigned long FLOW_ANOMALY_TIMEOUT = 60UL * 1000UL; // 60 second not detecting water flow = anomaly
unsigned long flowAnomalyTimer = 0;                      
bool pompaFault = false;                                  // True if there is anomaly
unsigned long lastLcdTime = 0;
const unsigned long lcdInterval = 3000;                   // Change display every 3 seconds
int lcdPage = 0;

// Cache Data untuk LCD
float disp_tempUdara, disp_hum, disp_tempAir, disp_ppm, disp_ph, disp_lux, disp_distance, disp_debit;
bool disp_sensorError, disp_airRendah, disp_airPenuh;
int disp_menit;

// Timer Variables
unsigned long lastLoopTime = 0;
const unsigned long loopInterval = 1000;                  // Interval for Main Program
// const unsigned long loopInterval = 5000;                  // Interval for Main Program
unsigned long lastMqttTime = 0;
const unsigned long mqttInterval = 5000;                // Interval for Sending Data to MQTT
// const unsigned long mqttInterval = 300000;                // Interval for Sending Data to MQTT
unsigned long lastReconnectAttempt = 0;

// Interrupt
void IRAM_ATTR countPulse() { flowPulses++; }

void setup() {
  Serial.begin(115200);

  // Open Memory Space Named as "pengaturan"
  preferences.begin("pengaturan", false);

  // Take the Saved Time Zones (Default: 7/WIB)
  zona_waktu_aktif = preferences.getInt("tz", 7);

  // WiFi & MQTT Setup
  espClient.setInsecure();
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(mqtt_callback);
  setup_wifi();

  // Apply the Time Zone when Booting
  Serial.println("Menyinkronkan waktu...");
  configTime(zona_waktu_aktif * 3600, 0, "pool.ntp.org");
  Serial.println("Sinkron!");

  // Sensors Initialization
  pinMode(FLOW_SENSOR_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(FLOW_SENSOR_PIN), countPulse, RISING);
  dht.begin();
  sensors.begin();
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // Actuators Initialization
  for(int i = 0; i < 9; i++) {
    pinMode(pinRelay[i], OUTPUT);
    digitalWrite(pinRelay[i], LOW); // OFF when start
  }
  servoPump.attach(PUMP_PIN);
  servoParanet.attach(PARANET_PIN);

  // LCD Initialization
  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0); lcd.print("   SYSTEM BOOTING   ");
  lcd.setCursor(0, 1); lcd.print(" AGRI-HUB SMART SYSTEM");
  delay(2000);
  lcd.clear();
}

void loop() {
  if (!client.connected()) {
    unsigned long currentMillis = millis();
    if (currentMillis - lastReconnectAttempt > 5000) {
      lastReconnectAttempt = currentMillis;
      // Trying to reconnect, if failed the main program still running
      if (reconnect()) {
        lastReconnectAttempt = 0;
      }
    }
  } else {
    client.loop(); // Only run the MQTT loop if connected
  }

  unsigned long currentMillis = millis();

  // =================================================================
  // BLOCK 1: EXECUTED EVERY 5 SECONDS (READ SENSORS 7 CONTROL LOGICS)
  // =================================================================
  if (currentMillis - lastLoopTime >= loopInterval) {
    lastLoopTime = currentMillis;

    // Time Initialization
    struct tm timeinfo;
    int menit_sejak_tengah_malam = 0;
    
    if (getLocalTime(&timeinfo)) {
      menit_sejak_tengah_malam = (timeinfo.tm_hour * 60) + timeinfo.tm_min;
    }

    // Read Humidity & Temperature from DHT22
    float hum = dht.readHumidity();
    float tempUdara = dht.readTemperature();

    // Read Water Temperature from DS18B20
    sensors.requestTemperatures();
    float tempAir = sensors.getTempCByIndex(0);
    
    // Read Water Discharge
    float debit = flowPulses * 0.1; 
    flowPulses = 0;  // Reset every 5 seconds

    // Read Analog Sensor (TDS, pH, LDR)
    float ec  = map(analogRead(TDS_PIN), 0, 4095, 100, 250) / 100.0;
    float ph  = map(analogRead(PH_PIN), 0, 4095, 0, 1400) / 100.0;  
    float ldr = analogRead(LDR_PIN);

    // Read Ultrasonic Sensor
    digitalWrite(TRIG_PIN, LOW); 
    delayMicroseconds(2);
    digitalWrite(TRIG_PIN, HIGH); 
    delayMicroseconds(10);
    digitalWrite(TRIG_PIN, LOW);
    float duration = pulseIn(ECHO_PIN, HIGH, 30000);

    // Calculation for Desired Variable
    float distance = 0.0;
    bool sensor_ultrasonik_error = false;
    bool air_tandon_rendah = false;
    bool air_tandon_penuh = false;

    if (duration > 0) {
      distance = (duration * 0.034 / 2);
      air_tandon_rendah = (distance >= JARAK_AIR_RENDAH);
      air_tandon_penuh = (distance <= JARAK_AIR_PENUH);
    } else {
      distance = -1.0; 
      sensor_ultrasonik_error = true;
    }

    // Simpan data untuk LCD
    disp_tempUdara = tempUdara;
    disp_hum = hum;
    disp_tempAir = tempAir;
    disp_ppm = ec * 500;
    disp_ph = ph;
    disp_lux = pow((RL10 * 1e3 * pow(10.0, GAMMA) / (10000 * (1 / ((3.3 / (ldr * (3.3 / 4095))) - 1)))), (1.0 / GAMMA));
    disp_distance = distance;
    disp_debit = debit;
    disp_sensorError = sensor_ultrasonik_error;
    disp_airRendah = air_tandon_rendah;
    disp_airPenuh = air_tandon_penuh;
    disp_menit = menit_sejak_tengah_malam;

    float ppm = disp_ppm;
    float lux = disp_lux;
    bool jam_siang = (menit_sejak_tengah_malam >= 360 && menit_sejak_tengah_malam < 1080);

    // --- ACTUATOR CONTROL LOGICS ---
    
    // Water Temp. Threshold: 18 - 28 C
    if (tempAir > 28) {
      digitalWrite(pinRelay[5], HIGH); 
    } else if (tempAir < 18) {
      digitalWrite(pinRelay[5], LOW);  
    } else {
      digitalWrite(pinRelay[5], LOW);
    }

    // Air Temp. Threshold: 20 - 30 C & Air Humidity Threshold: 60% - 80%
    if (hum > 80) {
      digitalWrite(pinRelay[4], HIGH);
      digitalWrite(pinRelay[6], LOW);  
    } else if (hum < 60 || tempUdara > 30) { 
      digitalWrite(pinRelay[4], LOW);  
      digitalWrite(pinRelay[6], HIGH); 
    } else { 
      digitalWrite(pinRelay[4], LOW);  
      digitalWrite(pinRelay[6], LOW);  
    }

    // Light Intensity Threshold: 2000 - 4000 lux
    if (jam_siang && lux < 2000) {
      digitalWrite(pinRelay[8], HIGH);
    } else {
      digitalWrite(pinRelay[8], LOW); 
    }

    // Paranet
    if (lux > 4000) {
      servoParanet.write(90); 
    } else {
      servoParanet.write(0);  
    }

    // Water Nutrition Threshold: 1000 - 1200 ppm
    if (ppm < 1000) {
      digitalWrite(pinRelay[3], HIGH); 
    } else {
      digitalWrite(pinRelay[3], LOW);
    }
    if (sensor_ultrasonik_error) {
      digitalWrite(pinRelay[7], LOW);
    } else if (air_tandon_penuh) {
      digitalWrite(pinRelay[7], LOW);
    } else if (ppm > 1200 || air_tandon_rendah) {
      digitalWrite(pinRelay[7], HIGH); 
    } else {
      digitalWrite(pinRelay[7], LOW);
    }

    // Water pH Threshold: 5.5 - 6.5
    if (ph < 5.5) {
      digitalWrite(pinRelay[1], HIGH); 
      digitalWrite(pinRelay[2], LOW);  
    } else if (ph > 6.5) {
      digitalWrite(pinRelay[1], LOW);  
      digitalWrite(pinRelay[2], HIGH); 
    } else {
      digitalWrite(pinRelay[1], LOW);
      digitalWrite(pinRelay[2], LOW);
    }

    // Anomaly Detection & pompa_utama controls
    if (!pompaFault && debit <= 5.0) {
      if (flowAnomalyTimer == 0) {
        flowAnomalyTimer = millis();
      } else if (millis() - flowAnomalyTimer >= FLOW_ANOMALY_TIMEOUT) {
        pompaFault = true;
        Serial.println("PERINGATAN: Anomali debit air! Pompa utama OFF.");
      } 
    } else if (debit > 0.0) {
      flowAnomalyTimer = 0; 
    }

    if (pompaFault) {
      digitalWrite(pinRelay[0], LOW);
      servoPump.write(0);            
    } else {
      digitalWrite(pinRelay[0], HIGH);
      servoPump.write(90);             
    }


    // =================================================================
    // BLOCK 2: EXECUTED EVERY 5 MINUTES (SENDING JSON VIA MQTT)
    // =================================================================
    if (currentMillis - lastMqttTime >= mqttInterval) {
      lastMqttTime = currentMillis;

      StaticJsonDocument<512> sensors;
      StaticJsonDocument<512> actuators;
      StaticJsonDocument<512> status;

      // Sensors Payload
      sensors["time"]              = menit_sejak_tengah_malam;
      sensors["suhu_udara"]        = tempUdara;
      sensors["kelembapan_udara"]  = hum;
      sensors["suhu_air"]          = tempAir;
      sensors["ppm"]               = ppm;
      sensors["ph_air"]            = ph;
      sensors["intensitas_cahaya"] = lux;
      sensors["jarak_ke_air"]      = distance;
      sensors["debit_air"]         = debit;

      // Actuators Payload
      actuators["time"]           = menit_sejak_tengah_malam;
      actuators["pompa_utama"]    = (servoPump.read() > 45) ? "ON" : "OFF";
      actuators["pompa_ph_up"]    = (digitalRead(pinRelay[1]) == HIGH) ? "ON" : "OFF";
      actuators["pompa_ph_down"]  = (digitalRead(pinRelay[2]) == HIGH) ? "ON" : "OFF";
      actuators["pompa_nutrisi"]  = (digitalRead(pinRelay[3]) == HIGH) ? "ON" : "OFF";
      actuators["kipas_luar"]     = (digitalRead(pinRelay[4]) == HIGH) ? "ON" : "OFF";
      actuators["kipas_tandon"]   = (digitalRead(pinRelay[5]) == HIGH) ? "ON" : "OFF";
      actuators["mist_sprayer"]   = (digitalRead(pinRelay[6]) == HIGH) ? "ON" : "OFF";
      actuators["solenoid_valve"] = (digitalRead(pinRelay[7]) == HIGH) ? "ON" : "OFF";
      actuators["grow_light"]     = (digitalRead(pinRelay[8]) == HIGH) ? "ON" : "OFF";
      actuators["paranet"]        = (servoParanet.read() > 45) ? "TERTUTUP" : "TERBUKA";

      // Status Payload
      status["status_pompa_utama"] = pompaFault ? "FAULT" : "ON";

      if (sensor_ultrasonik_error) {
        status["status_tandon"] = "ERROR_SENSOR";
      } else if (air_tandon_penuh) {
        status["status_tandon"] = "PENUH";
      } else if (air_tandon_rendah) {
        status["status_tandon"] = "RENDAH";
      } else {
        status["status_tandon"] = "NORMAL";
      }

      // Serialize (object -> string)
      String jsonbuf_sensor, jsonbuf_actuator, jsonbuf_status;
      serializeJson(sensors, jsonbuf_sensor);
      serializeJson(actuators, jsonbuf_actuator);
      serializeJson(status, jsonbuf_status);

      // Publish to Broker (EMQX)
      client.publish("agri-hub/sensor", jsonbuf_sensor.c_str());    
      client.publish("agri-hub/aktuator", jsonbuf_actuator.c_str()); 
      client.publish("agri-hub/status", jsonbuf_status.c_str());  

      Serial.println("--- DATA TERKIRIM KE MQTT ---");
      Serial.println(jsonbuf_sensor);
      Serial.println(jsonbuf_actuator);
      Serial.println(jsonbuf_status);
      Serial.println("-----------------------------");
    }
  }

  if (millis() - lastLcdTime >= lcdInterval) {
    lastLcdTime = millis();
    updateLCDDisplay();
    lcdPage = (lcdPage + 1) % 8; // Change page 0 to 4
  }
}

void setup_wifi() {
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) { 
    delay(500); 
    Serial.print("."); 
  }
  Serial.println("WiFi Terhubung!");
}

boolean reconnect() {
  if (WiFi.status() != WL_CONNECTED) {
    return false; 
  }
  
  Serial.print("Menghubungkan ke MQTT Broker...");
  if (client.connect("AGRI-HUB", mqtt_user, mqtt_pass)) {
    Serial.println(" Terhubung!");
    client.subscribe("agri-hub/config");
    return true;
  } else {
    Serial.print(" Gagal, rc=");
    Serial.println(client.state());
    return false;
  }
}

// MQTT Callback
void mqtt_callback(char* topic, byte* payload, unsigned int length) {
  // Convert payload to string
  String message((char*)payload, length);

  // If message for config topic
  if (String(topic) == "agri-hub/config") {
    StaticJsonDocument<200> doc;
    DeserializationError error = deserializeJson(doc, message);
    
    if (!error && doc.containsKey("zona_waktu")) {
      // Take value from user
      zona_waktu_aktif = doc["zona_waktu"]; 
      
      // Save Permanent into Memory
      preferences.putInt("tz", zona_waktu_aktif); 
      
      // Apply New Time Zones into the System
      configTime(zona_waktu_aktif * 3600, 0, "pool.ntp.org");
      
      Serial.print("Berhasil! Zona waktu diubah ke GMT+");
      Serial.println(zona_waktu_aktif);
    }

    if (!error && doc.containsKey("reset_pompa")) {
      pompaFault = false;
      flowAnomalyTimer = 0;
      Serial.println("Fault pompa utama berhasil direset melalui MQTT.");
    }
  }
}

void updateLCDDisplay() {
  lcd.clear();
  char buffer[21];

  switch (lcdPage) {
    case 0: // SENSOR - SECTION 1
      lcd.setCursor(0, 0); lcd.print("=== DATA SENSOR 1 ==");
      snprintf(buffer, sizeof(buffer), "Suhu Udara:%2.1fC Hum:%2.0f%%", disp_tempUdara);
      lcd.setCursor(0, 1); lcd.print(buffer);
      snprintf(buffer, sizeof(buffer), "Hum. Udara:%2.1fC PPM:%4.0f", disp_hum);
      lcd.setCursor(0, 2); lcd.print(buffer);
      snprintf(buffer, sizeof(buffer), "Suhu Air  :%2.1f  Lux:%4.0f", disp_tempAir);
      lcd.setCursor(0, 3); lcd.print(buffer);
      break;

    case 1: // SENSOR - SECTION 2
      lcd.setCursor(0, 0); lcd.print("=== DATA SENSOR 2 ==");
      snprintf(buffer, sizeof(buffer), "PPM    :%2.0f%%", disp_ppm);
      lcd.setCursor(0, 1); lcd.print(buffer);
      snprintf(buffer, sizeof(buffer), "pH Air :%4.0f", disp_ph);
      lcd.setCursor(0, 2); lcd.print(buffer);
      snprintf(buffer, sizeof(buffer), "Lux    :%4.0f", disp_lux);
      lcd.setCursor(0, 3); lcd.print(buffer);
      break;

    case 2: // SENSOR - SECTION 3
      lcd.setCursor(0, 0); lcd.print("=== DATA SENSOR 3 ==");
      snprintf(buffer, sizeof(buffer), "Debit Air : %2.1f L/m", disp_debit);
      lcd.setCursor(0, 1); lcd.print(buffer);
      if (disp_sensorError) {
        lcd.setCursor(0, 2); lcd.print("Jarak Air : ERROR   ");
      } else {
        snprintf(buffer, sizeof(buffer), "Jarak Air : %3.1f cm", disp_distance);
        lcd.setCursor(0, 2); lcd.print(buffer);
      }
      snprintf(buffer, sizeof(buffer), "Waktu     : %02d:%02d", disp_menit / 60, disp_menit % 60);
      lcd.setCursor(0, 3); lcd.print(buffer);
      break;

    case 3: // AKTUATOR - SECTION 1
      lcd.setCursor(0, 0); lcd.print("== DATA AKTUATOR 1 ==");
      snprintf(buffer, sizeof(buffer), "Pompa Utama:%-3s", (servoPump.read() > 45) ? "ON" : "OFF");
      lcd.setCursor(0, 1); lcd.print(buffer);
      snprintf(buffer, sizeof(buffer), "pH-Up      :%-3s", (digitalRead(pinRelay[1]) == HIGH) ? "ON" : "OFF");
      lcd.setCursor(0, 2); lcd.print(buffer);
      snprintf(buffer, sizeof(buffer), "pH-Down    :%-3s", (digitalRead(pinRelay[2]) == HIGH) ? "ON" : "OFF");
      lcd.setCursor(0, 3); lcd.print(buffer);
      break;

    case 4: // AKTUATOR - SECTION 2
      lcd.setCursor(0, 0); lcd.print("== DATA AKTUATOR 2 ==");
      snprintf(buffer, sizeof(buffer), "Nutrisi     :%-3s", (digitalRead(pinRelay[3]) == HIGH) ? "ON" : "OFF");
      lcd.setCursor(0, 1); lcd.print(buffer);
      snprintf(buffer, sizeof(buffer), "Kipas luar  :%-3s", (digitalRead(pinRelay[4]) == HIGH) ? "ON" : "OFF");
      lcd.setCursor(0, 2); lcd.print(buffer);
      snprintf(buffer, sizeof(buffer), "Kipas Tandon:%-3s", (digitalRead(pinRelay[5]) == HIGH) ? "ON" : "OFF");
      lcd.setCursor(0, 3); lcd.print(buffer);
      break;

    case 5: // AKTUATOR - SECTION 3
      lcd.setCursor(0, 0); lcd.print("== DATA AKTUATOR 3 ==");
      snprintf(buffer, sizeof(buffer), "Sprayer : %-3s", (digitalRead(pinRelay[6]) == HIGH) ? "ON" : "OFF");
      lcd.setCursor(0, 1); lcd.print(buffer);
      snprintf(buffer, sizeof(buffer), "Solenoid: %-3s", (digitalRead(pinRelay[7]) == HIGH) ? "ON" : "OFF");
      lcd.setCursor(0, 2); lcd.print(buffer);
      snprintf(buffer, sizeof(buffer), "G.Light : %-3s Prnt:%s", (digitalRead(pinRelay[8]) == HIGH) ? "ON" : "OFF", (servoParanet.read() > 45) ? "TUTUP" : "BUKA");
      lcd.setCursor(0, 3); lcd.print(buffer);
      break;
    
    case 6: // AKTUATOR - SECTION 4
      lcd.setCursor(0, 0); lcd.print("== DATA AKTUATOR 4 ==");
      snprintf(buffer, sizeof(buffer), "Paranet:%s", (servoParanet.read() > 45) ? "TUTUP" : "BUKA");
      lcd.setCursor(0, 3); lcd.print(buffer);
      break;

    case 7: // STATUS SISTEM
      lcd.setCursor(0, 0); lcd.print("=== STATUS SISTEM ==");
      snprintf(buffer, sizeof(buffer), "Pompa Utama: %-7s", pompaFault ? "FAULT" : "NORMAL");
      lcd.setCursor(0, 1); lcd.print(buffer);
      
      if (disp_sensorError)       { lcd.setCursor(0, 2); lcd.print("Tandon  : SENS_ERR"); }
      else if (disp_airPenuh)     { lcd.setCursor(0, 2); lcd.print("Tandon  : PENUH   "); }
      else if (disp_airRendah)    { lcd.setCursor(0, 2); lcd.print("Tandon  : RENDAH  "); }
      else                        { lcd.setCursor(0, 2); lcd.print("Tandon  : NORMAL  "); }

      snprintf(buffer, sizeof(buffer), "Koneksi MQTT: %-6s", client.connected() ? "CONNECTED" : "OFFLINE");
      lcd.setCursor(0, 3); lcd.print(buffer);
      break;
  }
}